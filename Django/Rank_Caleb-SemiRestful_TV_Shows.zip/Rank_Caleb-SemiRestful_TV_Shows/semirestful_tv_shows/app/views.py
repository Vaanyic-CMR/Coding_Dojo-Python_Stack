from django.shortcuts import render, redirect
from . import models

# .strftime( '%B %d, %Y' )

# Create your views here.
def index( request ):
    return redirect( '/shows' )

def shows( request ):
    context = {
        'shows': models.Show.objects.all(),
    }
    return render( request, 'shows.html', context=context )

def new_show( request ):
    return render( request, 'new_show.html' )

def create_show( request ):
    s = models.Show.objects.create(
        title = request.POST['title'],
        network = request.POST['network'],
        release_date = request.POST['release_date'],
        desc = request.POST['desc']
    )
    return redirect( f'/shows/{s.id}' )

def view_show( request, show_id=None ):
    context = {
        'show': models.Show.objects.get( id=show_id )
    }
    return render( request, 'view_show.html', context=context)

def edit_show( request, show_id=None ):
    context = {
        'show': models.Show.objects.get( id=show_id )
    }
    return render( request, 'edit_show.html', context)

def update_show( request, show_id=None ):
    s = models.Show.objects.get( id=show_id )
    s.title = request.POST['title']
    s.network = request.POST['network']
    s.release_date = request.POST['release_date']
    s.desc = request.POST['desc']
    s.save()
    return redirect( f'/shows/{s.id}' )

def destroy( request, show_id=None ):
    s = models.Show.objects.get( id=show_id )
    s.delete()
    return redirect( '/shows' )